import pandas as pd
import numpy as np
import os

# Parameters
WINDOW_SIZE = 10
STEP_SIZE = 1

# Function to compute deltas
def compute_deltas(df):
    df['dax'] = df['ax'].diff().fillna(0)
    df['day'] = df['ay'].diff().fillna(0)
    df['daz'] = df['az'].diff().fillna(0)
    return df[['dax', 'day', 'daz']].reset_index(drop=True)

# Function to create overlapping windows
def create_windows(delta_df, label):
    windows = []
    labels = []
    for i in range(0, len(delta_df) - WINDOW_SIZE + 1, STEP_SIZE):
        window = delta_df.iloc[i:i+WINDOW_SIZE].values.flatten()  # Flatten the window
        windows.append(window)
        labels.append(label)
    return windows, labels

# File list
filenames = ['normal.csv', 'seizure.csv']

# Initialize storage
all_windows = []
all_labels = []

# Process each file
for file in filenames:
    df = pd.read_csv(file)

    # Keep only accelerometer data
    df = df[['ax', 'ay', 'az']]

    # Compute deltas
    delta_df = compute_deltas(df)

    # Extract label from filename
    label = os.path.splitext(os.path.basename(file))[0]

    # Create windows and labels
    windows, labels = create_windows(delta_df, label)

    # Append to dataset
    all_windows.extend(windows)
    all_labels.extend(labels)

# Create DataFrame
X = pd.DataFrame(all_windows)
X['label'] = all_labels

# Save to CSV
X.to_csv('final_dataset.csv', index=False)

print("✅ Dataset saved to final_dataset.csv")
print("Shape:", X.shape)
