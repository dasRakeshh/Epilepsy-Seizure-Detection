import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV files
normal_df = pd.read_csv("normal.csv")
seizure_df = pd.read_csv("seizure.csv")

# Calculate delta (current - previous) for each axis
delta_normal = normal_df[["ax", "ay", "az"]].diff().dropna()
delta_seizure = seizure_df[["ax", "ay", "az"]].diff().dropna()

# Plot delta for Normal Data
plt.figure(figsize=(15, 6))
plt.subplot(1, 2, 1)
plt.plot(delta_normal["ax"], label="Δax", color="blue")
plt.plot(delta_normal["ay"], label="Δay", color="green")
plt.plot(delta_normal["az"], label="Δaz", color="red")
plt.title("Delta - Normal Data")
plt.xlabel("Time Step")
plt.ylabel("Delta Acceleration")
plt.legend()
plt.grid(True)


# Plot delta for Seizure Data
plt.subplot(1, 2, 2)
plt.plot(delta_seizure["ax"], label="Δax", color="blue")
plt.plot(delta_seizure["ay"], label="Δay", color="green")
plt.plot(delta_seizure["az"], label="Δaz", color="red")
plt.title("Delta - Seizure Data")
plt.xlabel("Time Step")
plt.ylabel("Delta Acceleration")
plt.legend()
plt.grid(True)
plt.show()
